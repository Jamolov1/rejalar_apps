package com.example.rejalar_apps

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
